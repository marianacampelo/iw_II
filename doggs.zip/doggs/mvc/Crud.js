import connection from "./properties";

class Crud {

    // salvar dados 
    save(dog, callback){
        let sql = "insert into race set ?"
        connection.query(sql, dog, function(error,results,fields){
            if(error) throw error

            dog.id = results.insertId
            callback(results)
        })

        connection.end()

    }


}

export default Crud 